﻿Public Class frmBusUpdater
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs)


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub frmBusUpdater_Load(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

    End Sub

    Dim namesofbusesArray() As String = {"Bus#1", "Bus#2", "Bus#3", "Bus#4", "Bus#5", "Bus#6", "Bus#7", "Bus#8", "Bus#9", "Bus#10", "Bus#11", "Bus#12", "Bus#13", "Bus#14"}

    Dim namesofroutesArray() As String = {"Harding Avenue", "Hethwood A", "Hethwood B", "Main Street North", "Main Street South", "Patrick Henry Drive", "South Main –Airport", "Toms Creek", "University City Blvd", "Terminal"}

    'list of string arrays for bus assaingments. THIS NEEDS DOUBLE CHECKING> I THINK I DID SOMETHING WRONG HERE
    Dim busassignmentlist As New List(Of String) From {{"Bus#1", "Bus#2", "Bus#3", "Bus#4", "Bus#5", "Bus#6", "Bus#7", "Bus#8", "Bus#9", "Bus#10", "Bus#11", "Bus#12", "Bus#13", "Bus#14"}, {"Harding Avenue", "Hethwood A", "Hethwood B", "Main Street North", "Main Street South", "Patrick Henry Drive", "South Main –Airport", "Toms Creek", "University City Blvd", "Terminal"}}

    'This is the two dimensioanl array for the number of buses and the demand for each route.

    Dim mylistArray() As String = {{"Bus#1", "Bus#2", "Bus#3", "Bus#4", "Bus#5", "Bus#6", "Bus#7", "Bus#8", "Bus#9", "Bus#10", "Bus#11", "Bus#12", "Bus#13", "Bus#14"}, {"500", "1000", "800", "400", "1200", "300", "900", "1000", "900"}}

    'Demand forcast ARRAY
    Dim demandArray() As String = {"500", "1000", "800", "400", "1200", "300", "900", "1000", "900"}
End Class
